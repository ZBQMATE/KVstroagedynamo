package edu.buffalo.cse.cse486586.simpledynamo;

import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;


public class SimpleDynamoProvider extends ContentProvider {

	static final String TAG = SimpleDynamoActivity.class.getSimpleName();
	static final String[] PORTS = {"11108","11112","11116","11120","11124"};
	static final String[] AVDS = {"5554","5556","5558","5560","5562"};
	static final String[] SAVDS = {"5562","5556","5554","5558","5560"};
	static final int[] SID = {4,1,0,2,3};
	static final int SERVER_PORT = 10000;
	private ArrayList<Integer> joinedavd = new ArrayList<Integer>();
	private ArrayList<Integer> remain_key = new ArrayList<Integer>();
	private ArrayList<Integer> remain_val = new ArrayList<Integer>();
	private int this_avd = 0;
	private HashSet<String> stored = new HashSet<String>();
	static final String cutter = "#Lzj#";
	static final String cutterb = "&Y Z&";
	private static int cnt = 0;
	private String qrs = "";
	private AtomicBoolean sys_qa = new AtomicBoolean(false);
	private AtomicBoolean sys_qall = new AtomicBoolean(false);

	public int findavd(int mode) {
		// 1 for next, -1 for prev

		int id = this_avd;
		int flg = 0;
		try {
			//Log.v(TAG, "FINDAVD " + Integer.toString(joinedavd.size()));
			String this_hash = genHash(AVDS[this_avd]);
			String btm = "zzzz";
			if (mode == -1) {
				btm = "!!!!";
			}
			for (int i = 0; i < joinedavd.size(); i = i + 1) {
				//Log.v(TAG, "in joined avd " + AVDS[joinedavd.get(i)]);
				String avd_hash = genHash(AVDS[joinedavd.get(i)]);
				if (mode * avd_hash.compareTo(this_hash) > 0) {
					if (mode * avd_hash.compareTo(btm) < 0) {
						btm = avd_hash;
						//id = i;
						id = joinedavd.get(i);

						flg = 1;
					}
				}
			}
			if (flg == 0) {
				for (int i = 0; i < joinedavd.size(); i = i + 1) {
					String avd_hash = genHash(AVDS[joinedavd.get(i)]);
					if (mode * avd_hash.compareTo(btm) < 0) {
						btm = avd_hash;
						//id = i;
						id = joinedavd.get(i);
					}
				}
			}
		}
		catch(Exception e) {
			Log.e(TAG, "findavd failed");
		}
		return id;

	}

	public int findnd(String key) {
		int id = this_avd;
		try {
			for (int i = 0; i < 5; i = i + 1) {
				String tmp = genHash(SAVDS[i]);
				if (tmp.compareTo(genHash(key)) > 0) {
					id = i;
					break;
				}
			}
		}
		catch(Exception e) {
			Log.e(TAG, "findnd failed");
		}
		return id;
	}



	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		int nextavd = findavd(1);
		if (selection.equals("@")) {
			stored = new HashSet<String>();
		}
		else if (selection.equals("*")) {
			String msg = "ALLDEL" + cutter + AVDS[this_avd];
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
		}
		else {
			try{
				stored.remove(selection);
			}
			catch (Exception e) {
				Log.v(TAG, "No delete");
			}
			String msg = "DELETE" + cutter + selection;
			int tgt_avd1 = findnd(selection);
			int tgt_avd2 = (tgt_avd1 + 1) % 5;
			int tgt_avd3 = (tgt_avd1 + 2) % 5;
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[SID[tgt_avd1]]);
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[SID[tgt_avd2]]);
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[SID[tgt_avd3]]);
		}



		return 0;
	}

	public int alldel(String start_point) {
		stored = new HashSet<String>();
		if (start_point.equals(AVDS[this_avd])) return 1;
		int nextavd = findavd(1);
		String msg = "ALLDEL" + cutter + start_point;
		new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
		return 0;
	}

	public int secondDelete(String key) {
		try{
			stored.remove(key);
		}
		catch (Exception e) {
			Log.v(TAG, "No seconddelete");
		}
		return 0;
	}


	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		int nextavd = findavd(1);
		//Log.v(TAG, "INSERT  " + Integer.toString(nextavd));
		String filename = (String) values.get("key");
		String string = (String) values.get("value");
		String msg = "INSERT" + cutter + filename + cutter + string + cutter + "st";
		new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[this_avd]);

		return uri;
	}

	public int secondInsert(String key, String value, String md) {

		if (md.equals("ps")) {
			String filename = key;
			String string = value;
			FileOutputStream outputStream;
			try {
				outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
				outputStream.write(string.getBytes());
				outputStream.close();
				stored.add(filename);
			} catch (IOException e) {
				Log.e(TAG, "File write failed");
			}

			return 0;
		}

		int tgt_avd1 = 0;
		int tgt_avd2 = 1;
		int tgt_avd3 = 2;
		try {
			for (int i = 0; i < 5; i = i + 1) {
				if (genHash(SAVDS[i]).compareTo(genHash(key)) > 0) {
					tgt_avd1 = i;
					break;
				}
			}
		}
		catch(Exception e) {
			Log.e(TAG, "ghvd failed");
		}
		tgt_avd2 = (tgt_avd1 + 1) % 5;
		tgt_avd3 = (tgt_avd1 + 2) % 5;
		tgt_avd1 = SID[tgt_avd1];
		tgt_avd2 = SID[tgt_avd2];
		tgt_avd3 = SID[tgt_avd3];

		if (tgt_avd1 == this_avd) {
			String filename = key;
			String string = value;
			FileOutputStream outputStream;
			try {
				outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
				outputStream.write(string.getBytes());
				outputStream.close();
				stored.add(filename);
			} catch (IOException e) {
				Log.e(TAG, "File write failed");
			}
		}
		else {
			String msg = "INSERT" + cutter + key + cutter + value + cutter + "ps";
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd1]);
		}

		if (tgt_avd2 == this_avd) {
			String filename = key;
			String string = value;
			FileOutputStream outputStream;
			try {
				outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
				outputStream.write(string.getBytes());
				outputStream.close();
				stored.add(filename);
			} catch (IOException e) {
				Log.e(TAG, "File write failed");
			}
		}
		else {
			String msg = "INSERT" + cutter + key + cutter + value + cutter + "ps";
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd2]);
		}

		if (tgt_avd3 == this_avd) {
			String filename = key;
			String string = value;
			FileOutputStream outputStream;
			try {
				outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
				outputStream.write(string.getBytes());
				outputStream.close();
				stored.add(filename);
			} catch (IOException e) {
				Log.e(TAG, "File write failed");
			}
		}
		else {
			String msg = "INSERT" + cutter + key + cutter + value + cutter + "ps";
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd3]);
		}

		return 0;
	}



	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
		for (int i = 0; i < 5; i = i+1) {
			if (PORTS[i].equals(myPort)) {
				this_avd = i;
			}
		}

		joinedavd = new ArrayList<Integer>();
		for (int i = 0; i < 5; i = i + 1) {

			int avdid = i;
			joinedavd.add(avdid);
			//Log.v(TAG, "joinedavd " + Integer.toString(avdid));
		}

		try {
			/*
			 * Create a server socket as well as a thread (AsyncTask) that listens on the server
			 * port.
			 *
			 * AsyncTask is a simplified thread construct that Android provides. Please make sure
			 * you know how it works by reading
			 * http://developer.android.com/reference/android/os/AsyncTask.html
			 */
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
		} catch (IOException e) {
			/*
			 * Log is a good way to debug your code. LogCat prints out all the messages that
			 * Log class writes.
			 *
			 * Please read http://developer.android.com/tools/debugging/debugging-projects.html
			 * and http://developer.android.com/tools/debugging/debugging-log.html
			 * for more information on debugging.
			 */
			Log.e(TAG, "Can't create a ServerSocket");
			return false;
		}
		String msg = "INITIAL" + cutter + Integer.toString(this_avd);
		for (int i = 0; i < 5; i = i+1) {
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[i]);
		}
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
						String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		MatrixCursor cursor = new MatrixCursor(new String[]{"key", "value"});
		try {

			int nextavd = findavd(1);
			if (selection.equals("@")) {
				Iterator hiter = stored.iterator();
				Log.v(TAG, "MSIII");
				for (String key : stored) {
					// = hiter.next();
					//Log.v(TAG, "KEY   "+key);
					InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
					BufferedReader br = new BufferedReader(ipta);
					String value = br.readLine();
					cursor.addRow(new Object[]{key, value});
				}
				return cursor;
			} else if (selection.equals("*")) {
				sys_qall.set(true);
				Log.v(TAG, "startGQ " + PORTS[nextavd]);
				qrs = "";
				String msg = "GLOBALQUERY" + cutter + PORTS[this_avd];
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);

				Log.v(TAG, "waitGQ");
				synchronized (sys_qall) {
					while (sys_qall.get()) {
						try {
							sys_qall.wait();
						}catch (Exception e){}
					}
				}


				Log.v(TAG, qrs);
				String rst_list[] = qrs.split(cutterb);
				Log.v(TAG, "rst_list.length " + Integer.toString(rst_list.length));

				for (int i = 1; i < rst_list.length; i = i + 2) {
					//Log.v(TAG, "this is " + rst_list[i]);
					cursor.addRow(new Object[]{rst_list[i], rst_list[i + 1]});
				}

				Log.v(TAG, "why im dead");
				return cursor;
			} else {

				//Log.v(TAG, "AAA");

				int tgt_avd1 = findnd(selection);
				int tgt_avd2 = (tgt_avd1 + 1) % 5;
				int tgt_avd3 = (tgt_avd1 + 2) % 5;

				tgt_avd1 = SID[tgt_avd1];
				tgt_avd2 = SID[tgt_avd2];
				tgt_avd3 = SID[tgt_avd3];

				sys_qa.set(true);

				qrs = "";
				String msg = "QUERY" + cutter + selection + cutter + PORTS[this_avd];
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd1]);
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd2]);
				new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[tgt_avd3]);

				//Log.v(TAG, "bbb" + PORTS[nextavd]);
				synchronized (sys_qa){
					while(sys_qa.get()){
						try{
							sys_qa.wait();
						}catch(Exception e){}
					}
				}

				cursor.addRow(new Object[]{selection, qrs});
				Log.v(TAG, "!!!result"+qrs);
				return cursor;
			}
		}
		catch(Exception e) {
			Log.e(TAG, "Query failed");
		}
		return cursor;
	}

	public int secondQuery(String key, String start_point) {


		try {
			//Log.v(TAG, "ddd");
			String value = "msi";
			InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
			BufferedReader br = new BufferedReader(ipta);
			value = br.readLine();
			MatrixCursor cursor = new MatrixCursor(new String[]{"key", "value"});
			cursor.addRow(new Object[]{key, value});
			//return cursor;
			//Log.v(TAG, "eee");
			String msg = "QUERST" + cutter + value;
			new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, start_point);


		} catch (Exception e) {
			Log.e(TAG, "secondQueryin failed");
		}

		return 0;
	}


	public int snd(String prt, String msg) {

		new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, prt);

		return 0;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
					  String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	private String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}


	// servertask
	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];

			/*
			 * TODO: Fill in your server code that receives messages and passes them
			 * to onProgressUpdate().
			 */

			Socket sk = null;
			String ss = "";
			while (1 == 1) {
				try {
					sk = serverSocket.accept();
					//ObjectInputStream ois = new ObjectInputStream(sk.getInputStream());

					//ss = (String) ois.readObject();
					InputStream is = sk.getInputStream();

					byte[] msgRecv = new byte[10000];
					int messageLength = is.read(msgRecv, 0, 10000);
					for (int i = 0; i < messageLength; i++) {
						ss += (char) msgRecv[i];
					}


					//publishProgress(ss);
					String msg_list[] = ss.split(cutter);
					String msg_type = msg_list[0];
					Log.v(TAG, "ServerTask GOT " + ss);
					if (msg_type.equals("INITIAL")) {
						int avdid = Integer.parseInt(msg_list[1]);
						String rm = "MBT";
						for (int i = 0; i < remain_key.size(); i = i+1) {
							rm = rm + cutterb;
							rm = rm + remain_key.get(i);
							rm = rm + cutterb;
							rm = rm + remain_val.get(i);
						}
						String msg = "REPLY" + cutter + rm;
						snd(PORTS[avdid], msg);

					}
					if (msg_type.equals("REPLY")) {
						String rm = msg_list[1];
						String rm_list[] = rm.split(cutterb);
						for (int i = 1; i < rm_list.length; i = i + 2) {
							String filename = rm_list[i];
							String string = rm_list[i + 1];
							FileOutputStream outputStream;
							try {
								outputStream = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
								outputStream.write(string.getBytes());
								outputStream.close();
								stored.add(filename);
							} catch (IOException e) {
								Log.e(TAG, "File write failed");
							}
						}

					}

					if (msg_type.equals("AVDLIST")) {
						joinedavd = new ArrayList<Integer>();
						for (int i = 1; i < msg_list.length; i = i + 1) {

							int avdid = Integer.parseInt(msg_list[i]);
							joinedavd.add(avdid);
							//Log.v(TAG, "joinedavd " + Integer.toString(avdid));
						}
					}
					if (msg_type.equals("INSERT")) {
						secondInsert(msg_list[1], msg_list[2], msg_list[3]);
					}
					if (msg_type.equals("DELETE")) {
						secondDelete(msg_list[1]);
					}
					if (msg_type.equals("ALLDEL")) {
						alldel(msg_list[1]);
					}
					if (msg_type.equals("QUERY")) {
						//Log.v(TAG, "ccc");
						secondQuery(msg_list[1], msg_list[2]);
					}
					if (msg_type.equals("QUERST")) {
						qrs = msg_list[1];
						//Log.v(TAG, "fff");
						synchronized (sys_qa) {
							sys_qa.set(false);
							sys_qa.notify();
						}
					}
					if (msg_type.equals("GLOBALQUERY")) {
						String bse = "";
						if (msg_list.length > 2) {
							bse = msg_list[2];
						}
						Log.v(TAG, "GQ1");
						Iterator hiter = stored.iterator();
						for (String key : stored) {
							//String key = hiter.next();
							InputStreamReader ipta = new InputStreamReader(getContext().openFileInput(key));
							BufferedReader br = new BufferedReader(ipta);
							String value= br.readLine();
							bse = bse + cutterb;
							bse = bse + key;
							bse = bse + cutterb;
							bse = bse + value;
						}
						Log.v(TAG, "GQ2" + bse);
						if (msg_list[1].equals(PORTS[this_avd])) {

							qrs = bse;
							Log.v(TAG, "GQ3");
							synchronized (sys_qall) {
								sys_qall.set(false);
								sys_qall.notify();
							}
						}
						else {
							int nextavd = findavd(1);
							String msg = "GLOBALQUERY" + cutter + msg_list[1] + cutter + bse;
							Log.v(TAG, "GQ4");
							snd(PORTS[nextavd], msg);
							//new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, PORTS[nextavd]);
						}
					}






				} catch (IOException e) {
					e.printStackTrace();
				}
				ss = "";
				if (sk == null) {
					break;
				}
				if (sk.isInputShutdown()) {
					break;
				}
			}

			return null;
		}


	}

	private class ClientTask extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... msgs) {
			String message = msgs[0];
			String port = msgs[1];

			try {
                /*
                String remotePort = REMOTE_PORT0;
                if (msgs[1].equals(REMOTE_PORT0))
                    remotePort = REMOTE_PORT1;



                 */

				String msgToSend = msgs[0];
				String targetPort = msgs[1];
				/*
				 * TODO: Fill in your client code that sends out a message.
				 */

                /*
                PrintWriter msg = new PrintWriter(socket.getOutputStream());
                */

				Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
						Integer.parseInt(targetPort));
				OutputStream os;
				os = socket.getOutputStream();
				byte[] ba = (msgToSend).getBytes();
				os.write(ba);
				//Log.v(TAG, "ClientTask FINISH " + msgToSend);




				//Socket socket;
				//String remotePort;
				//remotePort = targetPort;
				//socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
				//       Integer.parseInt(remotePort));
				//Log.v(TAG, "ClientTask READY TO FIRE");
				//if (msgToSend.length() > 0) {
				//    ObjectOutputStream stt = new ObjectOutputStream(socket.getOutputStream());
				//    stt.writeObject(msgToSend);
				//    stt.flush();
				//    Log.v(TAG, "ClientTask FINISH " + msgToSend);
				// }

				//socket.close();
			} catch (UnknownHostException e) {
				Log.e(TAG, "ClientTask UnknownHostException");
			} catch (IOException e) {
				Log.e(TAG, "ClientTask socket IOException");
			}



			return null;
		}


	}

}
